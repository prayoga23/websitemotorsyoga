<section id="gambar" class="d-flex flex-column justify-content-center align-items-center">
    <div class="gambar-container">
        <h1 style="color:rgb(247, 83, 12);" class="text-center">About Us</h1>
        <strong class="text-light text-center">&nbsp;&nbsp;&nbsp;&nbsp;Tentang Kami</strong>
    </div>
</section>
<div class="line"></div>

<section id="profile">
    <div class="container-fluid">
        <h2 class="mb-2">About us</h2>
        <p class="text-justify">Yoga Motors Merupakan lembaga perusahaan yang bergerak di bidang otomotive khusus
            kendaraan mobil sport. Melayani berbagai macam komponen yang dibutuhkan mobil sport atau disebut spare part
        </p>
        <p class="text-justify">Kami juga bisa memperbaiki mobil sport apapun yang dibutuhkan pelanggan dan memberikan
            yang terbaik. Layaknya teman, Yoga Motors ingin tumbuh bersama dengan para penggila motors sport. Kami ada
            untuk memberikan good vibes dan memberikan semangat dalam memulai langkah mewujudkan mimpi menjadi
            kenyataan.
            Dengan memberikan yang terbaik memodifikasi mobil anda supaya bisa memberikan lebih berbeda dari yang
            sebelumnya. Dan pasti nya lebih gagah dan keren.
        </p>
    </div>
</section>