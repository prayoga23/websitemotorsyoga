<section id="gambar" class="d-flex flex-column justify-content-center align-items-center">
    <div class="gambar-container">
        <h1 style="color:rgb(247, 83, 12);" class="text-center">YOGA MOTORS</h1>
        <strong class="text-light">Kita Bisa Modifikasi, Memperbaiki, Ganti Spare Part</strong>
    </div>
</section>
<section id="profile">
    <div class="container-fluid">
        <h2 class="mb-2">Profile</h2>
        <p class="text-justify">Yoga Motors Merupakan lembaga perusahaan yang bergerak di bidang otomotive
            khusus kendaraan mobil sport. Melayani berbagai macam komponen yang dibutuhkan mobil sport atau
            disebut spare part</p>
        <p class="text-justify">Kami juga bisa memperbaiki mobil sport apapun yang dibutuhkan pelanggan dan
            memberikan yang terbaik. Layaknya teman, Yoga Motors ingin tumbuh bersama dengan para penggila
            motors sport. Kami ada untuk memberikan good vibes dan memberikan semangat dalam memulai langkah
            mewujudkan mimpi menjadi kenyataan.
            Dengan memberikan yang terbaik memodifikasi mobil anda supaya bisa memberikan lebih berbeda dari
            yang sebelumnya. Dan pasti nya lebih gagah dan keren.
        </p>
    </div>
</section>
<div class="line"></div>

<section id="visimisi">
    <div class="container-fluid">
        <h2 class="mb-2">Visi & Misi</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-6 box-shadow">
                    <div class="card-body">
                        <h5 class="card-title">Visi</h5>
                        <p class="card-text">Menjadi bengkel pilihan utama pecinta otomotive mobil sport</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-6 box-shadow">
                    <div class="card-body">
                        <h5 class="card-title">Misi</h5>
                        <p class="card-text">
                        <p>• Memahami beragam kebutuhan pelanggan dan memberikan layanan alat mobil yang
                            tepat demi tercapainya kepuasan optimal bagi pelanggan, dengan memanfaatkan
                            teknologi supaya maksimal <br><br>• Memberikan nilai tambah bagi para
                            pengguna
                            untuk kenyamanan</p>
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<div class="line"></div>

<section id="produk">
    <div class="container-fluid">
        <h2 class="mb-2">Produk Kami</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/portfolio/portfolio-6.jpg" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/back-bumper.jpg" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/bodykit.jpg" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/back-bumper.jpg" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/portfolio/portfolio-6.jpg" width="50px" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4 box-shadow">
                    <img class="card-img-top" src="assets/img/bodykit.jpg" alt="Card image cap">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary">Detail</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary">Beli</button>
                            </div>
                            <small class="text-muted">9 mins</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<!-- ======= Contact Section ======= -->
<section id="kontak">
    <div class="container-fluid">

        <div class="section-title">
            <h2>Kontak Kami</h2>
            <p>Jika ada kesan, saran & masalah boleh hubungi kami</p>
        </div>

        <div class="row" data-aos="fade-in">

            <div class="col-lg-12 d-flex align-items-stretch">
                <div class="info">
                    <div class="address">
                         <h5><i class="bi bi-geo-alt"></i> Lokasi: Jl. Raya Perning, Desa Perning, RT 20 RW 02 Kecamatan Jetis, Kabupaten
                            Mojokerto, Jawa Timur 61352</h5>

                    </div>

                    <div class="email">
                    <h5><i class="bi bi-envelope"></i> Email: prayoga2np@gmail.com</h5>


                    </div>


                    <h5><i class="bi bi-phone"></i> No HP: +62 821-4164-5386</h5>

                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15825.940628333181!2d112.488749!3d-7.411432549999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e780ee4af66d131%3A0x15d629107b8c399a!2sJl.%20Raya%20Perning%20No.49%2C%20Perning%2C%20Kec.%20Jetis%2C%20Kabupaten%20Mojokerto%2C%20Jawa%20Timur%2061352!5e0!3m2!1sid!2sid!4v1655641113250!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

        </div>


    </div>
    <!-- ======= Contact Section ======= -->
    <section id="about">
        <div class="container-fluid">
            <h2 class="mb-2">About us</h2>
            <p class="text-justify">Untuk penyempurnaan kebutuhan mobil masa kini Sebagai perusahaan otomotive maka pada tanggal 27
                Mei 1990 Prayoga Nugroho Pangestu Sebagai CEO, pendiri Perusahaan Yoga Motors mengukuhkan bahwa
                perusahaan otomotive ini harus dijalankan supaya bisa memberikan kenyamanan, kemajuaan dan pasti bermanfaat bagi semua masyarakat.
            </p>
        </div>
    </section>