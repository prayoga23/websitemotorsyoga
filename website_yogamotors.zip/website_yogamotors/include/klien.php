  <!-- ======= Testimonials Section ======= -->
  <section id="testimonials" class="testimonials section-bg">
      <div class="container">

          <div class="section-title">
              <h2>Client Kami</h2>
          </div>

          <div class="row">
              <div class="col-md-4">
                  <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                  <h3>Saul Goodman</h3>
                  <h4>Ceo &amp; Founder</h4>
              </div><!-- End testimonial item -->

              <div class="col-md-4">
                  <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                  <h3>Sara Wilsson</h3>
                  <h4>Designer</h4>
              </div>
              <div class="col-md-4">
                  <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                  <h3>Jena Karlis</h3>
                  <h4>Store Owner</h4>
              </div>
              <div class="col-md-4">
                  <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                  <h3>Matt Brandon</h3>
                  <h4>Freelancer</h4>
              </div>
              <div class="col-md-4">
                  <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                  <h3>John Larson</h3>
                  <h4>Entrepreneur</h4>
              </div>
          </div>
          <div class="swiper-pagination"></div>
      </div>

      </div>
  </section><!-- End Testimonials Section -->