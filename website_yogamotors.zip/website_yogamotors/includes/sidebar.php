<nav id="sidebar">
    <div class="profile">
        <img src="assets/img/logo.png" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html">Yoga Motors</a></h1>
        <p class="text-light">Modification, Repair, PIMP</p>
        <div class="social-links mt-2 text-center">
            <a href="#" class="twitter"><i class="bi-twitter"></i></a>
            <a href="#" class="facebook"><i class="bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi-instagram"></i></a>
        </div>
    </div>

    <ul class="list-unstyled components">
        <li class="nav-item active">
            <a class="nav-link" href="index.php">Home</a>
        </li>
        <li>
            <a href="index.php?include=artikel">Artikel</a>
        </li>
        <li>
            <a href="index.php?include=event">Event </a>
        </li>
        <li>
            <a href="index.php?include=galeri">Galery Foto</a>
        </li>
        <li>
            <a href="index.php?include=client">Client Kami</a>
        </li>
        <li>
            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Login</a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#" style="color: black;">Sign In</a>
                </li>
                <li>
                    <a href="#" style="color: black;">Sign Up</a>
                </li>
            </ul>
        </li>

    </ul>
</nav>