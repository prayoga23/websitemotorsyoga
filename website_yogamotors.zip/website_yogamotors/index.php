<!DOCTYPE html>
<html>

<head>
    <?php include("includes/head.php") ?>
</head>

<body>
    <div class="wrapper">
        <?php include("includes/sidebar.php") ?>
        <?php include("includes/navbar.php") ?>
        <?php
        //pemanggilan konten halaman index
        if (isset($_GET["include"])) {
            $include = $_GET["include"];
            if ($include == "galeri") {
                include("include/galeri.php");
            } else if ($include == "client") {
                include("include/klien.php");
            } else if ($include == "about") {
                include("include/about.php");
            } else if ($include == "artikel") {
                include("include/artikel.php");
            } else if ($include == "event") {
                include("include/event.php");
            } else {
                include("include/index.php");
            }
        } else {
            include("include/index.php");
        }
        ?>
    </div>
</body>
<?php include("includes/script.php"); ?>

</html>